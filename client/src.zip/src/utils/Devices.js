export const deviceTypes = ["OY1100","OY1110","OY1210","OY1310","OY1320","OY1700", "UNKNOWN","OY1400","OY1410","SmartValve","LR210","OY1600V1", "WaterIWMLR3","DigimondoMeter","OY1320V1","LandisGyr","OY1200","TetraedreMBUS"]
export const endpointTypes = ["CORLYSIS","HTTP","FIWARE","THINGSBOARD","MQTT"]
